from django.apps import AppConfig


class PhilLocConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'phil_loc'
